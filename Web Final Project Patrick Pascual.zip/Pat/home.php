<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['admin_name'])) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="style.css">
</head>
<style type="text/css">
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}
.container {
    max-width: 600px;
    margin: 50px auto;
    padding: 20px;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    text-align: center;
}
h1 {
    color: #333;
    font-size: 2em;
    margin-bottom: 20px;
}
nav ul {
    list-style-type: none;
    padding: 0;
}
nav ul li {
    display: inline;
    margin: 0 10px;
}
nav ul li a {
    text-decoration: none;
    color: #007BFF;
    font-weight: bold;
}
nav ul li a:hover {
    text-decoration: underline;
}
.link-primary {
    color: #007BFF;
    text-decoration: none;
    padding: 10px 15px;
    border: 2px solid #007BFF;
    border-radius: 5px;
    transition: background-color 0.3s, color 0.3s;
}
.link-primary:hover {
    background-color: #007BFF;
    color: #fff;
}

</style>
<body>
    <div class="container">
        <h1>Hello, <?php echo htmlspecialchars($_SESSION['name']); ?></h1>
        <nav>
            <ul>
                <li><a href="view_products.php" class="link-primary">View Products</a></li>
                <li><a href="logout.php" class="link-primary">Logout</a></li>
            </ul>
        </nav>
    </div>
</body>
</html>

<?php
} else {
    header("Location: index.php");
    exit();
}
?>
