<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add Products</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
        }

        .display-4 {
            margin-top: 0;
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .link_primary {
            display: block;
            text-align: center;
            margin-top: 10px;
            text-decoration: none;
            color: #007bff;
        }

        .link_primary:hover {
            color: #0056b3;
        }

        .alert {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #f44336;
            border-radius: 5px;
            color: #f44336;
            background-color: #ffebee;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="php/add.php" method="post">

            <h4 class="display-4">ADD PRODUCT</h4>
            <hr>
            <br>

            <?php if (isset($_GET['error'])) { ?>
                <div class="alert" role="alert">
                    <?php echo $_GET['error']; ?>
                </div>
            <?php } ?>

            <div class="form-group">
                <label for="product_name">Product Name</label>
                <input type="text" class="form-control" id="product_name" name="product_name" value="<?php if(isset($_GET['product_name'])) echo($_GET['product_name']); ?>" placeholder="Enter Product Name">
            </div>

            <div class="form-group">
                <label for="stock">Stock</label>
                <input type="text" class="form-control" id="stock" name="stock" value="<?php if(isset($_GET['stock'])) echo($_GET['stock']); ?>" placeholder="Enter Stock">
            </div>

            <button type="submit" class="btn btn-primary" name="add">Add Product</button>
            <a href="view_products.php" class="link_primary">View Product</a>

        </form>
    </div>
</body>
</html>
