<?php include "php/view.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Products</title>
</head>
<style type="text/css">
    /* General styling */
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

/* Container for centering content */
.container {
    max-width: 900px;
    margin: 50px auto;
    padding: 20px;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

/* Styling the form heading */
.display-4 {
    color: #333;
    font-size: 2em;
    margin-bottom: 20px;
}

/* Styling the success message */
.alert-success {
    color: #155724;
    background-color: #d4edda;
    border-color: #c3e6cb;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 20px;
}

/* Styling the table */
.table {
    width: 100%;
    margin-bottom: 20px;
    border-collapse: collapse;
}

.table thead {
    background-color: #343a40;
    color: #fff;
}

.table th,
.table td {
    padding: 10px;
    border: 1px solid #dee2e6;
    text-align: left;
}

.table-dark th,
.table-dark td {
    background-color: #454d55;
    color: #fff;
}

.table-dark th {
    font-weight: bold;
}

/* Styling the action buttons */
.btn {
    display: inline-block;
    padding: 10px 15px;
    border-radius: 5px;
    text-decoration: none;
    color: #fff;
    font-weight: bold;
    transition: background-color 0.3s ease;
}

.btn-success {
    background-color: #28a745;
    border: none;
}

.btn-success:hover {
    background-color: #218838;
}

.btn-danger {
    background-color: #dc3545;
    border: none;
}

.btn-danger:hover {
    background-color: #c82333;
}

.btn-primary {
    background-color: #007bff;
    border: none;
}

.btn-primary:hover {
    background-color: #0056b3;
}

/* Link right for aligning links to the right */
.link-right {
    text-align: right;
    margin-top: 20px;
}

/* Styling the logout button */
.logout {
    margin-left: 10px;
}

</style>
<body>
    <div class="container">
        <div class="box">
            <h4 class="display-4 text-center">VIEW PRODUCT</h4>
            <hr>
            <?php if (isset($_GET['success'])) { ?>
                <div class="alert alert-success" role="alert">
                    <?php echo htmlspecialchars($_GET['success']); ?>
                </div>
            <?php } ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Product Name</th>
                            <th scope="col">Stock</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        while ($rows = mysqli_fetch_assoc($result)) {
                            $i++;
                        ?>
                        <tr>
                            <th scope="row"><?php echo $i; ?></th>
                            <td><?php echo htmlspecialchars($rows['product_name']); ?></td>
                            <td><?php echo htmlspecialchars($rows['stock']); ?></td>
                            <td>
                                <a href="update.php?id=<?php echo $rows['id']; ?>" class="btn btn-success">Update</a>
                                <a href="php/delete.php?id=<?php echo $rows['id']; ?>" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            <?php } else { ?>
                <p>No products found.</p>
            <?php } ?>
            <div class="link-right">
                <a href="add_new.php" class="btn btn-success">Add Product</a>
                <a href="logout.php" class="btn btn-primary logout">Logout</a>
            </div>
        </div>
    </div>
</body>
</html>
